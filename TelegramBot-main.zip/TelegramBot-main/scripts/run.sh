#!/bin/bash

exec python3 /code/src/bot.py &
exec python3 /code/src/send.py